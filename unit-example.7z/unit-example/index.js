const frameworks = require('./frameworks');

frameworks.Jasmine();

frameworks.Mocha();

frameworks.Jest();